//
//  FirstPageVC.swift
//  DialPadLogin
//
//  Created by Tamta Topuria on 11/23/20.
//

import UIKit

class FirstPageVC: UIViewController {
    
    override func viewDidLoad() {
        
    }
    
    @IBAction func close(){
        dismiss(animated: true, completion: nil)
    }
}
