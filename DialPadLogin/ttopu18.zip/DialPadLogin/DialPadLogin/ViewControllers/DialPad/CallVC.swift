//
//  CallVC.swift
//  DialPadLogin
//
//  Created by Tamta Topuria on 11/23/20.
//

import UIKit

class CallVC: UIViewController {
    
    override func viewDidLoad() {
        
    }
    
    @IBAction func close(){
        dismiss(animated: true, completion: nil)
    }
}
