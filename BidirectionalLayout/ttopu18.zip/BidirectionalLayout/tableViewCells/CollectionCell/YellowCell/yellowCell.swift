//
//  yellowCell.swift
//  BidirectionalLayout
//
//  Created by Tamta Topuria on 12/18/20.
//

import UIKit

class yellowCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

}
