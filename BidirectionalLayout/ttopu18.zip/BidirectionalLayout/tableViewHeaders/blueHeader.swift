//
//  blueHeader.swift
//  BidirectionalLayout
//
//  Created by Tamta Topuria on 12/18/20.
//

import UIKit

class blueHeader: UITableViewHeaderFooterView {

    @IBOutlet var leftView: UIView!
    @IBOutlet var rightView: UIView!
    
//    override func layoutSubviews() {
//        super.layoutSubviews()
//
//        contentView.frame = contentView.frame.inset(by: UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10))
//    }

}
