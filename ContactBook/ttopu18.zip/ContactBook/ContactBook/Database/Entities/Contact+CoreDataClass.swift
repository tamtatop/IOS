//
//  Contact+CoreDataClass.swift
//  ContactBook
//
//  Created by Tamta Topuria on 1/7/21.
//
//

import Foundation
import CoreData

@objc(Contact)
public class Contact: NSManagedObject {

}
